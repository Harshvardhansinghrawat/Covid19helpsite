$("document").ready(function() {
  $(".a1").click(function() {
    $(".S2, .S3, .S4, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S1").addClass("block");
    $(".S1").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a2").click(function() {
    $(".S1, .S3, .S4, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S2").addClass("block");
    $(".S2").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a3").click(function() {
    $(".S1, .S2, .S4, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S3").addClass("block");
    $(".S3").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a4").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S4").addClass("block");
    $(".S4").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a5").click(function() {
    $(".S1, .S3, .S2, .S4, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S5").addClass("block");
    $(".S5").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a6").click(function() {
    $(".S1, .S3, .S2, .S5, .S4, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S6").addClass("block");
    $(".S6").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a7").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S4, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S7").addClass("block");
    $(".S7").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a8").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S4, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S8").addClass("block");
    $(".S8").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a9").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S4, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S9").addClass("block");
    $(".S9").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a10").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S4, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S10").addClass("block");
    $(".S10").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a11").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S4, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S11").addClass("block");
    $(".S11").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a12").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S4, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S12").addClass("block");
    $(".S12").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a13").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S4, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S13").addClass("block");
    $(".S13").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a14").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S4, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S14").addClass("block");
    $(".S14").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a15").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S4, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S15").addClass("block");
    $(".S15").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a16").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S4, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S16").addClass("block");
    $(".S16").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a17").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S4, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S17").addClass("block");
    $(".S17").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a18").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S4, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S18").addClass("block");
    $(".S18").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a19").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S4, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S19").addClass("block");
    $(".S19").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a20").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S4, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S20").addClass("block");
    $(".S20").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a21").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S4, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S21").addClass("block");
    $(".S21").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a22").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S4, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S22").addClass("block");
    $(".S22").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a23").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S4, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S23").addClass("block");
    $(".S23").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a24").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S4, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S24").addClass("block");
    $(".S24").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a25").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S25").addClass("block");
    $(".S25").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a26").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S4, .S27, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S26").addClass("block");
    $(".S26").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a27").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S4, .S28, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S27").addClass("block");
    $(".S27").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a28").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S4, .S29, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S28").addClass("block");
    $(".S28").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a29").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S4, .S30, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S29").addClass("block");
    $(".S29").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a30").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S4, .S29, .S31, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S29").addClass("block");
    $(".S30").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a31").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S4, .S30, .S29, .S32, .S33, .S34, .S35, .S36").addClass("none");
    $(".S31").addClass("block");
    $(".S31").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a32").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S4, .S30, .S31, .S29, .S33, .S34, .S35, .S36").addClass("none");
    $(".S32").addClass("block");
    $(".S32").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a33").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S4, .S30, .S31, .S32, .S29, .S34, .S35, .S36").addClass("none");
    $(".S33").addClass("block");
    $(".S33").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a34").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S4, .S30, .S31, .S32, .S33, .S29, .S35, .S36").addClass("none");
    $(".S34").addClass("block");
    $(".S34").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a35").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S4, .S30, .S31, .S32, .S33, .S34, .S29, .S36").addClass("none");
    $(".S35").addClass("block");
    $(".S35").removeClass("none");
  });
});

$("document").ready(function() {
  $(".a36").click(function() {
    $(".S1, .S3, .S2, .S5, .S6, .S7, .S8, .S9, .S10, .S11, .S12, .S13, .S14, .S15, .S16, .S17, .S18, .S19, .S20, .S21, .S22, .S23, .S24, .S25, .S26, .S27, .S28, .S4, .S30, .S31, .S32, .S33, .S34, .S35, .S29").addClass("none");
    $(".S36").addClass("block");
    $(".S36").removeClass("none");
  });
});
