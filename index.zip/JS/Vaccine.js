$("document").ready(function(){
  $(".la1").click(function() {
    $(".a1").removeClass("none");
    $(".a2, .a3, .a4, .a5").addClass("none");
  });
});

$("document").ready(function(){
  $(".la2").click(function() {
    $(".a2").removeClass("none");
    $(".a1, .a3, .a4, .a5").addClass("none");
  });
});

$("document").ready(function(){
  $(".la3").click(function() {
    $(".a3").removeClass("none");
    $(".a2, .a1, .a4, .a5").addClass("none");
  });
});

$("document").ready(function(){
  $(".la4").click(function() {
    $(".a4").removeClass("none");
    $(".a2, .a3, .a1, .a5").addClass("none");
  });
});

$("document").ready(function(){
  $(".la5").click(function() {
    $(".a5").removeClass("none");
    $(".a2, .a3, .a4, .a1").addClass("none");
  });
});



$("document").ready(function(){
  $(".b1").click(function(){
    $(".bp1").removeClass("none");
    $(".bpl1").addClass("none");
    $(".bp2, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl2, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b2").click(function(){
    $(".bp2").removeClass("none");
    $(".bpl2").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b3").click(function(){
    $(".bp3").removeClass("none");
    $(".bpl3").addClass("none");
    $(".bp1, .bp2, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl2, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b4").click(function(){
    $(".bp4").removeClass("none");
    $(".bpl4").addClass("none");
    $(".bp1, .bp3, .bp2, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl2, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b5").click(function(){
    $(".bp5").removeClass("none");
    $(".bpl5").addClass("none");
    $(".bp1, .bp3, .bp4, .bp2, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl2, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b6").click(function(){
    $(".bp6").removeClass("none");
    $(".bpl6").addClass("none");
    $(".bp1, .bp3, .bp4, .bp2, .bp5, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl2, .bpl5, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b7").click(function(){
    $(".bp7").removeClass("none");
    $(".bpl7").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp2, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl2, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b8").click(function(){
    $(".bp8").removeClass("none");
    $(".bpl8").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp2, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl2, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b9").click(function(){
    $(".bp9").removeClass("none");
    $(".bpl9").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp2, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl2, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b10").click(function(){
    $(".bp10").removeClass("none");
    $(".bpl10").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp2, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl2, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b11").click(function(){
    $(".bp11").removeClass("none");
    $(".bpl11").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp2, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl2, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b12").click(function(){
    $(".bp12").removeClass("none");
    $(".bpl12").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp22, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl22, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b13").click(function(){
    $(".bp13").removeClass("none");
    $(".bpl13").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp2, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl2, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b14").click(function(){
    $(".bp14").removeClass("none");
    $(".bpl14").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp2, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl2, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b15").click(function(){
    $(".bp15").removeClass("none");
    $(".bpl15").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp2, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl2, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b16").click(function(){
    $(".bp16").removeClass("none");
    $(".bpl16").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp2, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl2, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b17").click(function(){
    $(".bp17").removeClass("none");
    $(".bpl17").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp2, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl2, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b18").click(function(){
    $(".bp18").removeClass("none");
    $(".bpl18").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp2, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl2, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b19").click(function(){
    $(".bp19").removeClass("none");
    $(".bpl19").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp2, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl2, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b20").click(function(){
    $(".bp20").removeClass("none");
    $(".bpl20").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp2, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl2, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b21").click(function(){
    $(".bp21").removeClass("none");
    $(".bpl21").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp2, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl2, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b22").click(function(){
    $(".bp22").removeClass("none");
    $(".bpl22").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp2, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl2, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b23").click(function(){
    $(".bp23").removeClass("none");
    $(".bpl23").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp2, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl2, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b24").click(function(){
    $(".bp24").removeClass("none");
    $(".bpl24").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp2, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl2, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b25").click(function(){
    $(".bp25").removeClass("none");
    $(".bpl25").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp2, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl2, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b26").click(function(){
    $(".bp26").removeClass("none");
    $(".bpl26").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp2, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl2, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b27").click(function(){
    $(".bp27").removeClass("none");
    $(".bpl27").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp2, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl2, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b28").click(function(){
    $(".bp28").removeClass("none");
    $(".bpl28").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp2, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl2, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b29").click(function(){
    $(".bp29").removeClass("none");
    $(".bpl29").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp2, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl2, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b30").click(function(){
    $(".bp30").removeClass("none");
    $(".bpl30").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp2, .bp31, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl2, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b31").click(function(){
    $(".bp31").removeClass("none");
    $(".bpl31").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp2, .bp32, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl2, .bpl32, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b32").click(function(){
    $(".bp32").removeClass("none");
    $(".bpl32").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp2, .bp33, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl2, .bpl33, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b33").click(function(){
    $(".bp33").removeClass("none");
    $(".bpl33").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp2, .bp34, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl2, .bpl34, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b34").click(function(){
    $(".bp34").removeClass("none");
    $(".bpl34").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp2, .bp35, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl2, .bpl35, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b35").click(function(){
    $(".bp35").removeClass("none");
    $(".bpl35").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp2, .bp36").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl2, .bpl36").removeClass("none");
  });
});

$("document").ready(function(){
  $(".b36").click(function(){
    $(".bp36").removeClass("none");
    $(".bpl36").addClass("none");
    $(".bp1, .bp3, .bp4, .bp5, .bp6, .bp7, .bp8, .bp9, .bp10, .bp11, .bp12, .bp13, .bp14, .bp15, .bp16, .bp16, .bp17, .bp18, .bp19, .bp20, .bp21, .bp22, .bp23, .bp24, .bp25, .bp26, .bp27, .bp28, .bp29, .bp30, .bp30, .bp31, .bp32, .bp33, .bp34, .bp35, .bp2").addClass("none");
    $(".bpl1, .bpl3, .bpl4, .bpl5, .bpl6, .bpl7, .bpl8, .bpl9, .bpl10, .bpl11, .bpl12, .bpl13, .bpl14, .bpl15, .bpl16, .bpl16, .bpl17, .bpl18, .bpl19, .bpl20, .bpl21, .bpl22, .bpl23, .bpl24, .bpl25, .bpl26, .bpl27, .bpl28, .bpl29, .bpl30, .bpl30, .bpl31, .bpl32, .bpl33, .bpl34, .bpl35, .bpl2").removeClass("none");
  });
});
